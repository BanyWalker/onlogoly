package com.xiyuan.ontology;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OntologyApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
